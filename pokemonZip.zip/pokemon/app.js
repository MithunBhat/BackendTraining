var fs = require('fs');
class pocketMonsters {
    
    constructor(fromPath, toPath) {
        this.fromFilePath = `${fromPath}.json`;
        this.toFilePath = `${toPath}.json`;
    }

    readJsonData() {
        var data = fs.readFileSync(this.fromFilePath);
        return JSON.parse(data);
    }

    asyncReadJsonData(cb) {
        fs.readFile(this.fromFilePath, (err, data) => {
            if (err) throw err;
            var asyncData = JSON.parse(data);
            cb(asyncData);
        });
    }

    writeJsonData(finalData) {
        fs.writeFileSync(this.toFilePath, JSON.stringify(finalData, null, 2));
    }

    asyncWriteJsonData(finalData) {
        // console.log(finalData);
        fs.writeFile(this.toFilePath, JSON.stringify(finalData, null, 2), (err) => {
            if (err) throw err;
        });
    }

    includeRegularStats(element) {
        var nationalNumber = element.national_number;
        var name = element.name;
        var levels = [this.includeLevelStats(element)];
        return {nationalNumber,
            name,
            levels
        };
    }

    includeLevelStats(element) {
        var levelsObj = {
            name: (element.evolution !== null) ? element.evolution.name : element.name,
            skills:{
                total: element.total,
                hp: element.hp,
                attack: element.attack,
                defense: element.defense,
                spAtk: element.sp_atk,
                spDef: element.sp_def,
                speed: element.speed
            }
        }
        return levelsObj;
    }

    process = () =>  {
        var dataObj = this.readJsonData();
        var results = [];
        var pokeObj = {};
        dataObj.results.forEach((element) => {
            let result = results.find(resultEle => {
                return resultEle.nationalNumber === element.national_number;
            });
            if(result) {
                var levelStat = this.includeLevelStats(element);
                pokeObj.levels.push(levelStat);
            } else {
                pokeObj = this.includeRegularStats(element);
                results.push(pokeObj);
            }
        });
        // results.levels = results.levels.sort((a, b) => {
        //     return (a.skills.total - b.skills.total)
        // });
        this.writeJsonData(results);
    }

    asyncProcess = () =>  {
        // var results = [];
        // var pokeObj = {};
        var finalOutput = this.asyncReadJsonData((dataObj) => {
            var results = [];
            var pokeObj = {};
            dataObj.results.forEach((element) => {
                let result = results.find(resultEle => {
                    return resultEle.nationalNumber === element.national_number;
                });
                if(result) {
                    var levelStat = this.includeLevelStats(element);
                    pokeObj.levels.push(levelStat);
                } else {
                    pokeObj = this.includeRegularStats(element);
                    results.push(pokeObj);
                }
            });
            return results;
            // results.levels = results.levels.sort((a, b) => {
            //     return (a.skills.total - b.skills.total)
            // });
        });
        
        this.asyncWriteJsonData(finalOutput);
    }

}

var newRegion = new pocketMonsters('pokemon', 'pokeDex');
newRegion.process();
// newRegion.asyncProcess();